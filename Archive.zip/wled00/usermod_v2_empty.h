#pragma once

#include "wled.h"

//This is an empty v2 usermod template. Please see the file usermod_v2_example.h in the EXAMPLE_v2 usermod folder for documentation on the functions you can use!

class UsermodRenameMe : public Usermod {
  private:
    
  public:
    void setup() {
      
    }

    void loop() {
      
    }
};